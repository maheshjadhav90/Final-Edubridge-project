package com.laptopshopping.service;

import com.laptopshopping.model.Service;

public interface ServiceService {

	Service addService(Service service, int orderId);

}
